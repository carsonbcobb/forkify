export const proxy = "https://cors-anywhere.herokuapp.com/";
export const key = "af785e14a6be0decdc60a117abff62be";
